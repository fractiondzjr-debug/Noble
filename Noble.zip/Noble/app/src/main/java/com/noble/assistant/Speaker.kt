package com.noble.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Noble's voice. */
class Speaker(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ready = true
            }
        }
    }

    val isSpeaking: Boolean get() = tts?.isSpeaking == true

    fun speak(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "noble")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
