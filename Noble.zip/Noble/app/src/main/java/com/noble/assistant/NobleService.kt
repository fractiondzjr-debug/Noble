package com.noble.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

/**
 * Always-on listener. Say "Noble, <command>" in one breath,
 * or say "Noble" and then the command when it answers "Yes?".
 */
class NobleService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private lateinit var executor: ActionExecutor
    private var awakeUntil = 0L
    private var stopped = false

    private val wakeRe = Regex("\\b(noble|nobel|no bull)\\b", RegexOption.IGNORE_CASE)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        speaker = Speaker(this)
        executor = ActionExecutor(this)
        startAsForeground()
        listen()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        running = false
        stopped = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        speaker.shutdown()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Noble listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Noble is listening")
            .setContentText("Say \"Noble\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ---------- Speech recognition loop ----------

    private fun listen() {
        if (stopped) return
        if (speaker.isSpeaking) {            // don't listen to our own voice
            handler.postDelayed({ listen() }, 500)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speaker.speak("Speech recognition is not available on this phone.")
            stopSelf()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(listener)
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }
            )
        }
    }

    private fun relisten(delayMs: Long = 300) {
        handler.postDelayed({ listen() }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) handle(text)
            relisten()
        }

        override fun onError(error: Int) {
            // No speech / timeout are normal while idle. Wait longer if the engine is busy.
            relisten(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handle(text: String) {
        val now = SystemClock.elapsedRealtime()
        val wake = wakeRe.find(text)
        val command = when {
            wake != null -> text.substring(wake.range.last + 1).trim(' ', ',', '.', '!')
            now < awakeUntil -> text
            else -> return                       // not addressed to Noble
        }
        if (command.isEmpty()) {
            awakeUntil = now + 8_000
            speaker.speak("Yes?")
            return
        }
        awakeUntil = 0
        val reply = executor.execute(CommandParser.parse(command), command)
        speaker.speak(reply)
    }

    companion object {
        private const val CHANNEL = "noble_listening"
        @Volatile var running = false
    }
}
