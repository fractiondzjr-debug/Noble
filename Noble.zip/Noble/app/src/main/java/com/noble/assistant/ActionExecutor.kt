package com.noble.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.telecom.TelecomManager
import android.view.KeyEvent
import kotlin.math.abs

/** Performs a Command on the phone and returns a sentence for Noble to say. */
class ActionExecutor(private val ctx: Context) {

    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val log = ActivityLog.get(ctx)

    fun execute(cmd: Command, heard: String): String {
        val reply = try {
            run(cmd)
        } catch (e: Exception) {
            "Sorry, that did not work."
        }
        log.add(LogType.COMMAND, "\"$heard\" -> $reply")
        return reply
    }

    private fun run(cmd: Command): String = when (cmd) {
        is Command.OpenApp -> openApp(cmd.name)
        Command.MediaPlay -> media(KeyEvent.KEYCODE_MEDIA_PLAY, "Playing")
        Command.MediaPause -> media(KeyEvent.KEYCODE_MEDIA_PAUSE, "Paused")
        Command.MediaNext -> media(KeyEvent.KEYCODE_MEDIA_NEXT, "Next track")
        Command.MediaPrevious -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous track")
        is Command.PlayMusic -> playMusic(cmd.query)
        is Command.PlayVideo -> playVideo(cmd.query)
        is Command.VolumeStep -> {
            repeat(2) {
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (cmd.up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    if (it == 1) AudioManager.FLAG_SHOW_UI else 0
                )
            }
            if (cmd.up) "Volume up" else "Volume down"
        }
        is Command.VolumeSet -> {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max * cmd.percent / 100, AudioManager.FLAG_SHOW_UI)
            "Volume set to ${cmd.percent} percent"
        }
        Command.VolumeMax -> {
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                AudioManager.FLAG_SHOW_UI
            )
            "Maximum volume"
        }
        Command.VolumeMute -> {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "Muted"
        }
        is Command.TypeText -> a11y { if (it.typeText(cmd.text)) "Typed" else "Tap a text box first" }
        Command.DeleteWord -> a11y { if (it.deleteLastWord()) "Deleted" else "No text box selected" }
        Command.ClearText -> a11y { if (it.clearText()) "Cleared" else "No text box selected" }
        Command.PressEnter -> a11y { if (it.pressEnter()) "Done" else "I could not press enter here" }
        is Command.Navigate -> a11y { if (it.navigate(cmd.nav)) "Okay" else "I could not do that" }
        is Command.Click -> a11y { if (it.clickByLabel(cmd.label)) "Tapped ${cmd.label}" else "I cannot see ${cmd.label}" }
        Command.AnswerCall -> answerCall()
        Command.EndCall -> endCall()
        is Command.Report -> log.spokenSummary(cmd.period) + " Open Noble to see the full report."
        Command.Help -> "I can open apps, play music or videos, change volume, type for you, " +
            "navigate, handle calls, and report your activity."
        Command.Unknown -> "Sorry, I did not understand."
    }

    private fun a11y(block: (NobleAccessibilityService) -> String): String {
        val svc = NobleAccessibilityService.instance
            ?: return "Please turn on Noble in accessibility settings."
        return block(svc)
    }

    // ---------- Apps ----------

    private fun normalize(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = normalize(name)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val best = pm.queryIntentActivities(launcher, 0)
            .map { it to normalize(it.loadLabel(pm).toString()) }
            .filter { (_, label) ->
                label.isNotEmpty() &&
                    (label == q || label.contains(q) || (label.length >= 3 && q.contains(label)))
            }
            .minByOrNull { (_, label) -> abs(label.length - q.length) }
            ?: return "I could not find an app called $name"
        val intent = pm.getLaunchIntentForPackage(best.first.activityInfo.packageName)
            ?: return "I could not open $name"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "Opening ${best.first.loadLabel(pm)}"
    }

    // ---------- Media ----------

    private fun media(keyCode: Int, reply: String): String {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return reply
    }

    private fun playMusic(query: String): String {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            "Playing $query"
        } catch (e: Exception) {
            playVideo(query)  // no music app handles it, so fall back to YouTube
        }
    }

    private fun playVideo(query: String): String {
        val yt = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(yt)
            "Searching YouTube for $query"
        } catch (e: Exception) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(web)
            "Searching YouTube for $query"
        }
    }

    // ---------- Calls ----------

    private fun hasCallPermission() =
        ctx.checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) ==
            PackageManager.PERMISSION_GRANTED

    private fun answerCall(): String {
        if (!hasCallPermission()) return "I need phone permission to answer calls."
        ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
        return "Answering"
    }

    private fun endCall(): String {
        if (!hasCallPermission()) return "I need phone permission to end calls."
        val ended = ctx.getSystemService(TelecomManager::class.java).endCall()
        return if (ended) "Call ended" else "There is no active call"
    }
}
