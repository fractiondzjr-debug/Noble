package com.noble.assistant

enum class Nav { BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, SCREENSHOT, SCROLL_DOWN, SCROLL_UP }

sealed class Command {
    data class OpenApp(val name: String) : Command()
    object MediaPlay : Command()
    object MediaPause : Command()
    object MediaNext : Command()
    object MediaPrevious : Command()
    data class PlayMusic(val query: String) : Command()
    data class PlayVideo(val query: String) : Command()
    data class VolumeStep(val up: Boolean) : Command()
    data class VolumeSet(val percent: Int) : Command()
    object VolumeMax : Command()
    object VolumeMute : Command()
    data class TypeText(val text: String) : Command()
    object DeleteWord : Command()
    object ClearText : Command()
    object PressEnter : Command()
    data class Navigate(val nav: Nav) : Command()
    data class Click(val label: String) : Command()
    object AnswerCall : Command()
    object EndCall : Command()
    data class Report(val period: Period) : Command()
    object Help : Command()
    object Unknown : Command()
}

/** Turns a spoken sentence (wake word already removed) into a Command. */
object CommandParser {

    private val typeRe = Regex("^(type|write|dictate)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val openRe = Regex("^(open|launch|start)\\s+(.+)$")
    private val clickRe = Regex("^(tap|click|press|select)\\s+(on\\s+)?(the\\s+)?(.+)$")
    private val volNumRe = Regex("volume.*?(\\d{1,3})|(\\d{1,3}).*?volume")
    private val playRe = Regex("^(play|watch)\\s+(.+)$")

    fun parse(raw: String): Command {
        val original = raw.trim()
        val t = original.lowercase().trim(' ', '.', ',', '!', '?')
        if (t.isEmpty()) return Command.Unknown

        // Oral typing: keep the user's original casing
        typeRe.find(original.trim(' ', '.', ',', '!', '?'))?.let { return Command.TypeText(it.groupValues[2]) }
        when (t) {
            "delete", "delete word", "delete last word", "backspace" -> return Command.DeleteWord
            "clear", "clear text", "clear all", "delete all" -> return Command.ClearText
            "enter", "send", "send it", "search", "go" -> return Command.PressEnter
        }

        // Calls
        if (Regex("^(answer|accept|pick up|pickup)( the)?( call| phone)?$").matches(t)) return Command.AnswerCall
        if (Regex("^(end|cancel|reject|decline|drop|cut|hang up|hangup)( the)?( call| phone)?$").matches(t) ||
            t == "hang up" || t == "end call" || t == "reject call" || t == "decline call"
        ) return Command.EndCall

        // Volume
        if (t.contains("volume") || t == "mute" || t.contains("louder") || t.contains("quieter")) {
            if (t.contains("max") || t.contains("full")) return Command.VolumeMax
            if (t.contains("mute")) return Command.VolumeMute
            volNumRe.find(t)?.let { m ->
                val n = (m.groupValues[1].ifEmpty { m.groupValues[2] }).toInt().coerceIn(0, 100)
                return Command.VolumeSet(n)
            }
            if (t.contains("up") || t.contains("increase") || t.contains("raise") || t.contains("louder"))
                return Command.VolumeStep(true)
            if (t.contains("down") || t.contains("decrease") || t.contains("lower") ||
                t.contains("reduce") || t.contains("quieter")
            ) return Command.VolumeStep(false)
        }
        if (t == "mute") return Command.VolumeMute
        if (t == "turn it up") return Command.VolumeStep(true)
        if (t == "turn it down") return Command.VolumeStep(false)

        // Media
        when (t) {
            "play", "play music", "resume", "resume music", "continue" -> return Command.MediaPlay
            "pause", "pause music", "stop music", "stop", "pause video", "stop video" -> return Command.MediaPause
            "next", "next song", "next track", "skip", "skip song" -> return Command.MediaNext
            "previous", "previous song", "previous track", "last song" -> return Command.MediaPrevious
        }
        playRe.find(t)?.let { m ->
            val verb = m.groupValues[1]
            var q = m.groupValues[2]
            val isVideo = verb == "watch" || q.startsWith("video ") || q.endsWith(" on youtube") ||
                q.startsWith("youtube ")
            q = q.removePrefix("video ").removePrefix("youtube ").removePrefix("music ")
                .removeSuffix(" on youtube").removeSuffix(" on spotify").removeSuffix(" on youtube music").trim()
            return if (isVideo) Command.PlayVideo(q) else Command.PlayMusic(q)
        }

        // Navigation
        when (t) {
            "back", "go back" -> return Command.Navigate(Nav.BACK)
            "home", "go home", "home screen", "go to home screen" -> return Command.Navigate(Nav.HOME)
            "recents", "recent apps", "show recent apps", "app switcher" -> return Command.Navigate(Nav.RECENTS)
            "notifications", "open notifications", "show notifications" -> return Command.Navigate(Nav.NOTIFICATIONS)
            "quick settings", "open quick settings" -> return Command.Navigate(Nav.QUICK_SETTINGS)
            "lock", "lock screen", "lock phone" -> return Command.Navigate(Nav.LOCK)
            "screenshot", "take screenshot", "take a screenshot" -> return Command.Navigate(Nav.SCREENSHOT)
            "scroll down", "swipe up", "down" -> return Command.Navigate(Nav.SCROLL_DOWN)
            "scroll up", "swipe down", "up" -> return Command.Navigate(Nav.SCROLL_UP)
        }
        clickRe.find(t)?.let { return Command.Click(it.groupValues[4].trim()) }

        // Reports
        if (Regex("report|history|activity|what did i do|summary|usage").containsMatchIn(t)) {
            val p = when {
                t.contains("month") -> Period.MONTH
                t.contains("week") -> Period.WEEK
                else -> Period.DAY
            }
            return Command.Report(p)
        }

        if (t == "help" || t == "what can you do") return Command.Help

        openRe.find(t)?.let { return Command.OpenApp(it.groupValues[2].removePrefix("the ").removeSuffix(" app").trim()) }

        return Command.Unknown
    }
}
