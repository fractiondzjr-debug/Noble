package com.noble.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Records call activity (ringing, answered, ended) in the activity log. */
class CallStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state == lastState) return  // the system often sends duplicates
        val message = when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> "Incoming call ringing"
            TelephonyManager.EXTRA_STATE_OFFHOOK -> "Call in progress"
            TelephonyManager.EXTRA_STATE_IDLE -> if (lastState == null) null else "Call ended"
            else -> null
        }
        lastState = state
        message?.let { ActivityLog.get(context).add(LogType.CALL, it) }
    }

    companion object {
        private var lastState: String? = null
    }
}
