package com.noble.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class LogType { APP_OPENED, COMMAND, CALL }
enum class Period { DAY, WEEK, MONTH }

data class LogEntry(val ts: Long, val type: LogType, val detail: String)

/** Stores everything Noble sees or does, and builds daily / weekly / monthly reports. */
class ActivityLog private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "noble.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE logs(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ts INTEGER NOT NULL, type TEXT NOT NULL, detail TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_logs_ts ON logs(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(type: LogType, detail: String) {
        val values = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("type", type.name)
            put("detail", detail)
        }
        writableDatabase.insert("logs", null, values)
    }

    fun since(fromMillis: Long): List<LogEntry> {
        val out = mutableListOf<LogEntry>()
        readableDatabase.rawQuery(
            "SELECT ts, type, detail FROM logs WHERE ts >= ? ORDER BY ts ASC",
            arrayOf(fromMillis.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += LogEntry(c.getLong(0), LogType.valueOf(c.getString(1)), c.getString(2))
            }
        }
        return out
    }

    fun clearAll() {
        writableDatabase.delete("logs", null, null)
    }

    private fun startOf(period: Period): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        when (period) {
            Period.DAY -> {}
            Period.WEEK -> cal.add(Calendar.DAY_OF_YEAR, -6)    // last 7 days incl. today
            Period.MONTH -> cal.add(Calendar.DAY_OF_YEAR, -29)  // last 30 days incl. today
        }
        return cal.timeInMillis
    }

    private fun title(p: Period) = when (p) {
        Period.DAY -> "Today"
        Period.WEEK -> "Last 7 days"
        Period.MONTH -> "Last 30 days"
    }

    /** Short sentence Noble reads aloud. */
    fun spokenSummary(period: Period): String {
        val e = since(startOf(period))
        val apps = e.count { it.type == LogType.APP_OPENED }
        val cmds = e.count { it.type == LogType.COMMAND }
        val calls = e.count { it.type == LogType.CALL }
        val label = when (period) {
            Period.DAY -> "Today"; Period.WEEK -> "This week"; Period.MONTH -> "This month"
        }
        return "$label you opened $apps apps, gave me $cmds commands, and had $calls call events."
    }

    /** Full written report shown in the app. */
    fun report(period: Period): String {
        val entries = since(startOf(period))
        if (entries.isEmpty()) return "${title(period)}: nothing recorded yet."

        val sb = StringBuilder()
        sb.appendLine("NOBLE REPORT: ${title(period)}")
        sb.appendLine("=".repeat(32))
        sb.appendLine("Apps opened : ${entries.count { it.type == LogType.APP_OPENED }}")
        sb.appendLine("Commands    : ${entries.count { it.type == LogType.COMMAND }}")
        sb.appendLine("Call events : ${entries.count { it.type == LogType.CALL }}")
        sb.appendLine()

        val top = entries.filter { it.type == LogType.APP_OPENED }
            .groupingBy { it.detail }.eachCount()
            .entries.sortedByDescending { it.value }.take(8)
        if (top.isNotEmpty()) {
            sb.appendLine("Most used apps")
            top.forEach { sb.appendLine("  ${it.key}: ${it.value}x") }
            sb.appendLine()
        }

        if (period == Period.DAY) {
            sb.appendLine("Timeline")
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            entries.takeLast(300).forEach {
                sb.appendLine("${fmt.format(Date(it.ts))}  [${it.type.name.lowercase()}] ${it.detail}")
            }
        } else {
            sb.appendLine("Per day")
            val dayFmt = SimpleDateFormat("EEE d MMM", Locale.getDefault())
            entries.groupBy { dayFmt.format(Date(it.ts)) }.forEach { (day, list) ->
                sb.appendLine(
                    "  $day: ${list.count { it.type == LogType.APP_OPENED }} apps, " +
                        "${list.count { it.type == LogType.COMMAND }} commands, " +
                        "${list.count { it.type == LogType.CALL }} call events"
                )
            }
        }
        return sb.toString()
    }

    companion object {
        @Volatile private var instance: ActivityLog? = null
        fun get(ctx: Context): ActivityLog =
            instance ?: synchronized(this) {
                instance ?: ActivityLog(ctx).also { instance = it }
            }
    }
}
