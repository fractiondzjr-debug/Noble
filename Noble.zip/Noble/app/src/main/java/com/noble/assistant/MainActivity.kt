package com.noble.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Setup + reports screen. The real work happens in NobleService. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var toggle: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Noble"
            textSize = 34f
            gravity = Gravity.START
        })
        root.addView(TextView(this).apply {
            text = "Say \"Noble\" followed by a command."
            textSize = 15f
        })
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(16), 0, dp(8)) }
        root.addView(status)

        root.addView(button("1. Allow microphone & phone") { requestPerms() })
        root.addView(button("2. Turn on Noble accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        toggle = button("Start Noble") { toggleService() }
        root.addView(toggle)

        root.addView(TextView(this).apply {
            text = "Activity reports"
            textSize = 18f
            setPadding(0, dp(20), 0, dp(4))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Today" to Period.DAY, "Week" to Period.WEEK, "Month" to Period.MONTH).forEach { (n, p) ->
            row.addView(
                button(n) { output.text = ActivityLog.get(this).report(p) },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        root.addView(row)
        root.addView(button("Erase all recorded activity") {
            AlertDialog.Builder(this)
                .setMessage("Delete everything Noble has recorded?")
                .setPositiveButton("Delete") { _, _ ->
                    ActivityLog.get(this).clearAll(); output.text = "History erased."
                }
                .setNegativeButton("Cancel", null).show()
        })

        output = TextView(this).apply {
            textSize = 13f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, dp(12), 0, 0)
            setTextIsSelectable(true)
        }
        root.addView(output)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun granted(p: String) =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun mark(ok: Boolean) = if (ok) "✔" else "✘"

    private fun refreshStatus() {
        val mic = granted(Manifest.permission.RECORD_AUDIO)
        val phone = granted(Manifest.permission.ANSWER_PHONE_CALLS) &&
            granted(Manifest.permission.READ_PHONE_STATE)
        val a11y = NobleAccessibilityService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        status.text = "${mark(mic)} Microphone   ${mark(phone)} Phone calls\n" +
            "${mark(a11y)} Accessibility   ${mark(overlay)} Display over apps\n" +
            "${mark(NobleService.running)} Listening"
        toggle.text = if (NobleService.running) "Stop Noble" else "Start Noble"
    }

    private fun requestPerms() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refreshStatus()
    }

    private fun toggleService() {
        val intent = Intent(this, NobleService::class.java)
        if (NobleService.running) {
            stopService(intent)
        } else {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                requestPerms()
                return
            }
            ContextCompat.startForegroundService(this, intent)
        }
        status.postDelayed({ refreshStatus() }, 500)
    }
}
