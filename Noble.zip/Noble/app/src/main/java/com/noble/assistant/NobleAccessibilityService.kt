package com.noble.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Gives Noble "hands": navigation, tapping, scrolling and typing into the focused field.
 * It also logs which app comes to the foreground.
 */
class NobleAccessibilityService : AccessibilityService() {

    private var lastPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPackage || pkg == packageName) return
        val pm = packageManager
        // Only count real apps the user can launch (skips keyboards, system overlays)
        if (pm.getLaunchIntentForPackage(pkg) == null) return
        if (pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        lastPackage = pkg
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        ActivityLog.get(this).add(LogType.APP_OPENED, label)
    }

    // ---------- Navigation ----------

    fun navigate(nav: Nav): Boolean = when (nav) {
        Nav.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
        Nav.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
        Nav.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        Nav.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        Nav.QUICK_SETTINGS -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        Nav.LOCK -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        Nav.SCREENSHOT -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        Nav.SCROLL_DOWN -> scroll(forward = true)
        Nav.SCROLL_UP -> scroll(forward = false)
    }

    private fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findScrollable(child)?.let { return it }
        }
        return null
    }

    /** Taps the first clickable element whose text or description contains [label]. */
    fun clickByLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (match in root.findAccessibilityNodeInfosByText(label)) {
            var cur: AccessibilityNodeInfo? = match
            while (cur != null) {
                if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur = cur.parent
            }
        }
        return false
    }

    // ---------- Oral typing ----------

    private fun focusedInput(): AccessibilityNodeInfo? =
        rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun currentText(node: AccessibilityNodeInfo): String =
        if (node.isShowingHintText) "" else node.text?.toString().orEmpty()

    fun typeText(text: String): Boolean {
        val node = focusedInput() ?: return false
        val base = currentText(node)
        return setText(node, if (base.isEmpty()) text else "$base $text")
    }

    fun deleteLastWord(): Boolean {
        val node = focusedInput() ?: return false
        val words = currentText(node).trimEnd().split(" ")
        return setText(node, words.dropLast(1).joinToString(" "))
    }

    fun clearText(): Boolean {
        val node = focusedInput() ?: return false
        return setText(node, "")
    }

    /** Presses the keyboard's Enter / Send / Search key (Android 11+). */
    fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val node = focusedInput() ?: return false
        return node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    companion object {
        @Volatile var instance: NobleAccessibilityService? = null
    }
}
