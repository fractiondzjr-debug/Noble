# Noble: voice-activated phone assistant (Android)

Say **"Noble, open WhatsApp"**, or say **"Noble"** and wait for "Yes?", then give the command.

## Run it
1. Install **Android Studio**, choose *Open*, and select this `Noble` folder. Let Gradle sync.
2. Plug in an Android phone (9.0+) with USB debugging on, or use an emulator. A real phone is best for calls and the microphone.
3. Press **Run**.
4. In the app, tap the three setup buttons in order:
   1. Allow microphone & phone
   2. Turn on Noble accessibility (Settings > Accessibility > Noble)
   3. Allow display over other apps (so Noble can open apps from the background)
5. Tap **Start Noble**.

## Voice commands
| Area | Say |
|---|---|
| Open apps | "Noble, open YouTube" / "launch camera" |
| Music | "play music", "pause", "next song", "previous", "play Burna Boy" |
| Video | "watch funny cats", "play video Python tutorial", "play X on YouTube" |
| Volume | "volume up", "volume down", "volume 60", "max volume", "mute" |
| Oral typing | Tap a text box, then "type Hello, I am on my way" / "delete" / "clear" / "send" |
| Navigation | "go back", "go home", "recent apps", "notifications", "quick settings", "scroll down", "scroll up", "tap Send", "lock screen", "take a screenshot" |
| Calls | "answer call", "end call", "reject call", "hang up" |
| Reports | "what did I do today / this week / this month" (spoken summary; full report in the app) |

## Files
- `NobleService.kt`: always-on microphone listener and wake word "Noble"
- `CommandParser.kt`: turns sentences into commands (add your own phrases here)
- `ActionExecutor.kt`: opens apps, media, volume, calls
- `NobleAccessibilityService.kt`: typing, tapping, scrolling, back/home, app-usage logging
- `CallStateReceiver.kt`: logs incoming, answered and ended calls
- `ActivityLog.kt`: SQLite history and the day/week/month reports
- `MainActivity.kt`: setup screen and report viewer

## Limits to know about
- **Android only.** iPhones do not allow an app to answer calls or control other apps.
- **Wake word** uses the phone's speech recognizer, so it is not instant and may beep on some phones. For a battery-friendly, offline wake word, add Picovoice Porcupine later.
- **Calls:** answering and ending uses Android's `TelecomManager`. Some manufacturers limit it. The mic may not hear you once a call is connected, so "end call" is best said by voice before pickup or via speakerphone.
- **Activity log** records apps you open, calls (ringing / in progress / ended, not numbers) and Noble commands. It does not record screen contents or what you type. Data stays on the phone; "Erase" wipes it.
- **Reports:** Week = last 7 days, Month = last 30 days.
- Typing needs a focused text box; "send" works on Android 11+.
- Google Play restricts accessibility apps. Fine for personal use; publishing needs a justification.
